# 3D Drucker Webshop

>## Quickstart
>Get and Update all necessary modules:  
>```
>npm install
>```
>
>### Scripts
> (database setup, ...)
>
>### Start Frontend Angular Server [Home Page](http://localhost:4200/):
>
>```
>cd frontend
>ng serve
>```
>
>### Start Backend Node Server [Entry Point](http://localhost:5000/api/products/)
>
>```
>cd backend
>npm start
>```
>
>### Database ([See here](backend/src/models/database.model.ts))
>name: 'fwa'  
>login: 'root'  
>password: 'mymariadbpw'  

&nbsp;
## **TO-DO LIST**

>### - SCSS / CSS!  
- example:  
    2 websites(one with css / one with scss)  
    subjective opinion  
    differences  
- creativity  

&nbsp;
>### Core  functionality

- Database Connection  *[Alex]*  [- PARTLY DONE -]
    - ~~Mock Data function in product.router change to real data and split in model/controller/routes~~  
    - ~~SQL Script: add foreign keys?(need to be tested) (sql line 242)~~  

- Database Connection resulted in broken API requests  
    - API need rework for search function and category filter  

- Changes in Frontend to fit Database  [+ DONE +]
    - ~~(because mock data != database data)~~  
    - ~~product page: manufacturer / filament type / printing process~~
    - ~~depends on Database Connection~~  

- Administratorpage *[Kevin]*
    - POST
    - PUSH
    - DELETE
 
- Order Page  *[Lukas]*
    - Checkout Form (customer information, address, etc.)  
    - change database (no cart, no customer)
    - billing informations
    - inform user (confirmation email (mockup/console.log))

&nbsp;
>### Additional functionality

- Better Category Filter with more options  
    - multiple parameters
    - multiple selections  
    - [Geizhals example](https://geizhals.de/?cat=dr3d)
    - [Slider example](https://material.angular.io/components/slider/overview)  

- Searchfunction  
    - example:  
        - filament type name search  
        - description keyword search  
    - current:  
        - only product name  
        
&nbsp;
>### Minor changes

- price formatting  
- ~~Warehouse implementation~~ 
- SQL:  [- PARTLY DONE -]  
    - change database to our needs  
        - no customer!  
        - no warehouse!  
        - etc.  
    - foreign keys( **works without**)
    - ~~printing process only abbrevations~~ (or short_name and long_name)  
    - ~~typos?~~  
    - more product data  
- images  

>### Relevant for presentation

- Possible questions:
    - observable vs promise
    - template-based vs relative
- Unit Test(s)  
- Startup script  

&nbsp;
>## API Requests
>
>### GET 
>
>
>"/" : Get all products  
>"/manufacturer" : Get all manufacturers  
>"/filamentType" : Get all filament types  
>"/printingProcess" : Get all printing Processes  
>"/:productID" : Get product by ID 
> 
>>***only test data***  
>>"/search/:searchTerm" : Get products by productName  
>
>>***obsolete?/broken***  
>>"/manufacturer/id/:manufacturerId" : Get manufacturers by manufacturerId  
>>"/manufacturer/name/:manufacturerName" : Get products by manufacturerName  
>>
>>"/filamentType/:filamentTypeName" : Get products by filamentTypeName  
>>
>>"/printingProcess/:printingProcessName" : Get products by printingProcessName  
>
>>***what we need***
>>- API request for new search  
>>    - search terms can be part of:  
>>        - name  
>>        - manufacturer  
>>        - printing process  
>>        - filament type  
>>        - description
>>        - product size?  
>>- API requests for advanced filter  
>>      - get products by manufacturer (id)  
>>      - get products by filament type (id)  
>>      - get products by printing process(id)  
>>      - ...  
>>
