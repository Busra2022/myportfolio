export class Manufacturer{
    id!:number;
    name!:string;
}
export class FilamentType{
    id!:number;
    shortName!:string;
    longName!:string;
}
export class PrintingProcess{
    id!:number;
    name!:string;
}