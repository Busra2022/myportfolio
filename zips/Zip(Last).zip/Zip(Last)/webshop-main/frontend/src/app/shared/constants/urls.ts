const BASE_URL = 'http://localhost:5000';

export const PRODUCTS_URL = BASE_URL + '/api/products';
export const PRODUCTS_BY_SEARCH_URL = PRODUCTS_URL + '/search/';
export const PRODUCTS_MANUFACTURER_URL = PRODUCTS_URL + '/manufacturer';
export const PRODUCTS_BY_MANUFACTURER_URL = PRODUCTS_URL + '/manufacturer/name/';
export const PRODUCTS_FILAMENTYPES_URL = PRODUCTS_URL + '/filamentType';
export const PRODUCTS_BY_FILAMENTYPES_URL = PRODUCTS_URL + '/filamentType/';
export const PRODUCTS_PRINTINGPROCESS_URL = PRODUCTS_URL + '/printingProcess';
export const PRODUCTS_BY_PRINTINGPROCESS_URL = PRODUCTS_URL + '/printingProcess/';
export const PRODUCTS_BY_ID_URL = PRODUCTS_URL + '/';

