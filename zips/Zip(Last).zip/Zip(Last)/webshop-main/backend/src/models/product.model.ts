import { Sequelize, DataTypes } from 'sequelize'
import { sequelize } from './database.model'
import { Manufacturer } from './manufacturer.model'
import { FilamentType } from './filamentType.model'
import { PrintingProcess } from './printingProcess.model'

const Product = sequelize.define('product', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.STRING,
        allowNull: false
    },
    imageUrl: {
        type: DataTypes.STRING,
        allowNull: false
    },
    price: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    manufacturerId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model : Manufacturer,
            key: "id"
        },
    },
    filamentTypeId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model : FilamentType,
            key: "id"
        },
    },
    weight: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    maxPrintHeight: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    maxPrintWidth: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    maxPrintDepth: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    productHeight: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    productWidth: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    productDepth: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    printingProcessId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model : PrintingProcess,
            key: "id"
        },
    }
},
{
    timestamps: false,
    tableName: 'product',
    underscored: true,
    freezeTableName: true
})

Product.belongsTo(Manufacturer, {
    foreignKey: 'manufacturerId',
    as: 'manufacturer',
  })

Product.belongsTo(FilamentType, {
    foreignKey: 'filamentTypeId',
    as: 'filamentType',
  })

Product.belongsTo(PrintingProcess, {
    foreignKey: 'printingProcessId',
    as: 'printingProcess',
  })

async function getAll () {
    try {
        let product = await Product.findAll({
            include: [{
                model: Manufacturer,
                as: 'manufacturer',
                attributes: ['name'],
            },
            {
                model: FilamentType,
                as: 'filamentType',
                attributes: [['short_name', 'name']],
            },
            {
                model: PrintingProcess,
                as: 'printingProcess',
                attributes: ['name'],
              },]
        })
        return product
    } catch (error) {
        console.error("product.model:", error)
        let product = await Product.findAll()
        return product
    }
}

async function get (id) {
    try {
        let product = await Product.findByPk(id, {
            include: [{
                model: Manufacturer,
                as: 'manufacturer',
                attributes: ['name'],
            },
            {
                model: FilamentType,
                as: 'filamentType',
                attributes: [['short_name', 'name']],
            },
            {
                model: PrintingProcess,
                as: 'printingProcess',
                attributes: ['name'],
              },]
        })
        return product
    } catch (error) {
        console.error("product.model:", error)
        let product = await Product.findByPk(id)
        return product
    }
}

export {
    getAll,
    get,
    Product
}
