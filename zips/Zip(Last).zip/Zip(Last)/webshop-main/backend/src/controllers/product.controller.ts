import { get as getProduct, getAll as getAllProducts, Product} from '../models/product.model'

import { sampleProducts } from "../data";


async function getAllProductsAction (req, res) {
    try {
        let products = await getAllProducts()
        res.json(products)
    } catch (error) {
        // Using sample data, if database connection failed
        console.error("Product Database connection error. Using sample data")
        res.json(sampleProducts);
    }
}

async function getProductAction (req, res) {
    try {
        let id = req.params.productId
        let product = await getProduct(id)
        res.json(product?.dataValues)
    } catch (error) {
        // Using sample data, if database connection failed
        console.error("Product Database connection error. Using sample data")
        let productId = req.params.productId;
        let product = sampleProducts.find(product => product.id == productId)
        res.send(product);  // return Product by ID
    }

}

export {
    getAllProductsAction,
    getProductAction
}