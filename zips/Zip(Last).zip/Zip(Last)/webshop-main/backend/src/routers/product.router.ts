import { Router } from "express";
import {
  getAllProductsAction,
  getProductAction,
} from "../controllers/product.controller";

import {
  sampleFilamentType,
  samplePrintingProcess,
  sampleProducts,
} from "../data";

const router = Router();

// get all products
router.get("/", getAllProductsAction);
// get product by id
router.get("/:productId", getProductAction);

// necessary functions:
// get products by manufacturerId
// get products by filamentTypeId
// get products by printingProcessId

// Old functions for test data
router.get("/search/:searchTerm", (req, res) => {
  const searchTerm = req.params.searchTerm;
  const products = sampleProducts.filter((product) =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  res.send(products); // return all Products by Searchterm | Only Product name currently
});

router.get("/filamentType/:filamentTypeName", (req, res) => {
  const filamentTypeName = req.params.filamentTypeName;
  const products = sampleProducts.filter((product) =>
    product.filamentType?.includes(filamentTypeName)
  );
  res.send(products); // return all Products by Filament Type
});

router.get("/printingProcess/:printingProcessName", (req, res) => {
  const printingProcessName = req.params.printingProcessName;
  const products = sampleProducts.filter((product) =>
    product.printingProcess?.includes(printingProcessName)
  );
  res.send(products); // return all Products by printing Process
});
// end of old functions for test data

export { router };
