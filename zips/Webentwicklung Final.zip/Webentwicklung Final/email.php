<?php 
if (isset($_POST['submitForm'])){
   
    $firstname = $_POST['name'];
    $lastname = $_POST['lname'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $content="Von: $firstname $lastname\n Nachricht: $message";
    $recipient = "inf3954@hs-worms.de";
    $head = "Von: $email \r\n";
    
    mail($recipient, $subject, $content, $head) or die("Whoops! Da ist etwas schief gelaufen.");
    echo "Erfolgreich versendet!";
}
?>