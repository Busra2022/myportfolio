window.addEventListener("DOMContentLoaded", function () {
  const prozentRechner = document.querySelector("button[name=prozent]");
  prozentRechner.addEventListener("click", handleAddiereKlick);

  function handleAddiereKlick() {
    const grundwert = document.getElementById("grundwert").valueAsNumber;
    const prozentwert = document.getElementById("prozentwert").valueAsNumber;
    if (grundwert < 0) {
      window.alert("Grundwert darf nicht negativ sein");
    }
    if (prozentwert < 0) {
      window.alert("Prozentwert darf nicht negativ sein");
    }
    document.getElementById("prozentsatz").textContent =
      (prozentwert / grundwert) * 100;
  }

  // Game
  // Get the form and the submit button
  const form = document.getElementById("test-form");
  console.log(form);

  const submitButton = document.querySelector(".sbutton");

  // Add an event listener to the submit button
  submitButton.addEventListener("click", function (event) {
    // Prevent the form from submitting
    event.preventDefault();

    // Initialize the score to 0
    let score = 0;

    // Get the selected options for each question
    const q1 = form.elements.q1;
    const q2 = form.elements.q2;
    const q3 = form.elements.q3;
    const q4 = form.elements.q4;

    // Check the answers and update the score
    if (q1[2].checked) {
      score++;
    }
    if (q2[1].checked) {
      score++;
    }
    if (q3[0].checked) {
      score++;
    }
    if (q4[1].checked) {
      score++;
    }
    console.log(score);
    // Display the score
    alert(`You scored ${score} out of 4`);
    event.preventDefault();
  });
});
